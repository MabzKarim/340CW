package ts_gui;

import java.sql.*;
import java.util.ArrayList;
/**
 *
 * @author karimm9
 */
public interface InstructorRepo {
    //Define all the instructor operations for instructor table
    public void addInstructor(Instructor instr, Connection conn);
    public Instructor getInstructor(Instructor instructor);
    public ArrayList<Instructor> getAllInstructor();
    public void setInstructor(ArrayList list);    
    public ArrayList read(Connection conn);
    void write(Connection conn, String str, Instructor instructor);

}