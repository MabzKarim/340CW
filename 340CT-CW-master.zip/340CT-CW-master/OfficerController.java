package ts_gui;

import java.sql.Connection;
import java.text.*;
import java.util.*;
/**
 *
 * @author karimm9
 */
public class OfficerController {
    //Decalres all the data repositories
    SessionRepoImpl sessionRepo = new SessionRepoImpl();
    CourseRepoImpl courseRepo = new CourseRepoImpl();
    RoomRepoImpl roomRepo = new RoomRepoImpl();
    InstructorRepoImpl instructorRepo = new InstructorRepoImpl();
  
//---------------------------
//SESSION Controllers
//---------------------------
    
    //This operation adds the sessions to Session Repo
    public void add_session( int course_id, int room_id, int instructor_id, String start_date, String end_date, int time, Connection conn){
        //Declares a list which contains all of the dates between start_date and end_date with the corresponding day chosen by user
        ArrayList<String> dateList = new ArrayList<>();
        //Calls operation to store all dates between start_date and end_date with the corresponding day chosen by user
        generateDateList(start_date, end_date, dateList);
        
        //Iterates around each of dates between start_date and end_date
        for(int i = 0; i< dateList.size(); i++){
            //Assigns the Session Variables to the Session objects
            Session sess = new Session();
            sess.setSessionID(viewNextSessionID());
            sess.setCourseID(course_id);
            sess.setRoomID(room_id);
            sess.setInstructorID(instructor_id);
            sess.setDate(dateList.get(i));
            sess.setTime(time);
            
            //Adds the Session to the Repo
            sessionRepo.addSession(sess, conn);
        }
    }
    
    public void viewAvailableSessions(int instructor_id, int course_id, String start_date, String end_date, ArrayList<String> list_sessions, ArrayList<Integer> BookedTimesByInstructor, ArrayList<Integer> BookedTimesByRoom, Connection conn){
        ArrayList listRoom = roomRepo.getAllRoom();
        int MIN_HOUR = 8;
        int MAX_HOUR = 18;
        int course_length = viewDetailsCourse(course_id).getCourseLength() ;
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        sdf.setLenient(false);
        
        try {
            //if not valid, it will throw ParseException
            Date StartDate = sdf.parse(start_date);

            Date EndDate = sdf.parse(end_date);

            searchSessionByInstructorRoom(instructor_id, "Instructor", StartDate, EndDate, course_length, BookedTimesByInstructor, conn);

            for (int i = 0; i<listRoom.size(); i++){
                
                Room temp = (Room)listRoom.get(i);
                int room_id = temp.getRoomID();
                searchSessionByInstructorRoom(room_id, "Room", StartDate, EndDate, course_length, BookedTimesByRoom, conn);
                
                for (int x = MIN_HOUR; x < MAX_HOUR; x++){
                    if ( ((BookedTimesByInstructor.contains(x)) == false) & ((BookedTimesByRoom.contains(x)) == false)  ){
                        int EndTime = x  + course_length;
                        if ("Classroom".equals(temp.getRoomType())){
                            list_sessions.add("Room: " + temp.getRoomID() + "." + "Classroom ----------- " + x + ":00 - " +  EndTime + ":00");
                        } else {
                            list_sessions.add("Room: " + temp.getRoomID() + "." + "PC Room ------------ " + x + ":00 - " +  EndTime + ":00");
                        }
                    }
                }
                BookedTimesByRoom.clear();
            }

        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
    
    public void searchSessionByInstructorRoom(int ref, String ID_type, Date start_date, Date end_date, int course_length, ArrayList<Integer> BookedTimes, Connection conn){
        ArrayList list = sessionRepo.getAllSession();
        List<Session> listSessionsByInstructorRoom = new ArrayList<>();
        //FIRST SEARCH
        for (int i = 0; i<list.size(); i++){
            
            Session temp = (Session)list.get(i);
            
            String tempDate = temp.getDate();

            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            sdf.setLenient(false);
            
            int tempID = 0;
            
            if (ID_type == "Instructor"){
                tempID = temp.getInstructorID();
            } else if(ID_type == "Room"){
                tempID = temp.getRoomID();
            }            
            
            try {
                    //if not valid, it will throw ParseException

                    Date tempDateOfTheWeek = sdf.parse(tempDate);

                    SimpleDateFormat dayOfTheWeekFormat = new SimpleDateFormat("EEEE"); // the day of the week spelled out completely

                    String StartDay = dayOfTheWeekFormat.format(start_date);

                    String tempDay = dayOfTheWeekFormat.format(tempDateOfTheWeek);

                    if ((tempDateOfTheWeek.compareTo(start_date) >= 0) && (tempDateOfTheWeek.compareTo(end_date) <= 0) && (tempID == ref) && (StartDay.equals(tempDay)) ){

                        try{
                            listSessionsByInstructorRoom.add(temp);
                        } catch (NullPointerException ex){
                            System.out.println("Error :" + ex);
                        }
                    }

            } catch (ParseException e) {
                System.out.println("Error:" + e);
                e.printStackTrace();
            }
        }
        //SECOND SEARCH
        ArrayList listSessionswithUnavailTimes = new ArrayList();
        ArrayList timesUnavailable = new ArrayList();
        
        if ( (listSessionsByInstructorRoom == null) == false){
            for (int i = 0; i<listSessionsByInstructorRoom.size(); i++){
                Session temp = (Session)listSessionsByInstructorRoom.get(i);

                if (timesUnavailable.contains( temp.getTime() )){

                } else{
                    //CHANGE TIME FIELD TO INT IN SQL
                    timesUnavailable.add( temp.getTime() );
                    listSessionswithUnavailTimes.add(temp);
                }
            }

            //THIRD SEARCH
            ArrayList listCourse = courseRepo.getAllCourse();
            ArrayList listSessionLengths = new ArrayList();
            for (int i = 0; i<listSessionswithUnavailTimes.size(); i++){
                Session temp = (Session)listSessionswithUnavailTimes.get(i);

                for (int x = 0; x<listCourse.size(); x++){
                    Course tempCourse = (Course)listCourse.get(x);
                    if ( tempCourse.getCourseID() == temp.getCourseID()) {
                        listSessionLengths.add(tempCourse.getCourseLength());
                    }
                }
            }

            //FOURTH SEARCH
            for (int i = 0; i<timesUnavailable.size(); i++){
                BookedTimes.add( Integer.parseInt(timesUnavailable.get(i).toString()) );
                BookedTimes.add( Integer.parseInt(timesUnavailable.get(i).toString()) - (course_length -1 ) );
                for (int x = 0; x < Integer.parseInt( (listSessionLengths.get(i)).toString() ); x++){
                    BookedTimes.add( Integer.parseInt(timesUnavailable.get(i).toString()) + (x) );
                }
            }
        }
        BookedTimes.add(18 - (course_length - 1));
    }
    
    public void setSessionList(ArrayList list){
        sessionRepo.setSession(list);
    }
    
    ArrayList list = new ArrayList();       
    
    public int viewNextSessionID(){
        ArrayList list = sessionRepo.getAllSession();
        
        int i = list.size();
            
        Session temp = (Session)list.get(i - 1);
        int nextSessionID = temp.getSessionID() + 1;  
        return nextSessionID;
    }
    
//---------------------------
//COURSE Controllers
//---------------------------
    
    //This operation returns the Course record of a specified record by COURSE ID
    public Course viewDetailsCourse(int ref){
        //Assigns the repository to a list
        ArrayList course_list = courseRepo.getAllCourse();
        boolean found = false;
        int i = 0;
        //Iterates through the Course repository list until th record specified by ID is found
        while (i<course_list.size() && !found){
            Course temp = (Course)course_list.get(i);
            if (ref == temp.getCourseID()){
                //Assigns the record from the repo to a temporary object
                System.out.print("Course Details: \n Course ID: " +
                        ref + "\n Course Name: " +
                        temp.getCourseName() + "\n Course Length: " +
                        temp.getCourseLength() + "\n");
                
                found = true;
                //Returns the temporary object
                return temp;
            }
        i++;    
        }
        return null;
    }
    
    //This operation returns a list of all the courses with COURSE ID and COURSE NAME
    public void viewAllCourse(ArrayList<String> course_list){
        //Assigns the repository to a list
        ArrayList list = courseRepo.getAllCourse();
        
        if (list.size() > 0){
            //Iterates through the Course repository list
            for (int i = 0; i<list.size(); i++){
                //Assigns the records from the repo to a temporary object
                Course temp = (Course)list.get(i);
                //Adds each record of the field CourseID and Course Name to a new list seperated by ":" - For the user output
                course_list.add(temp.getCourseID() + ": " + temp.getCourseName());
            }
        }
    }
    
    //This operation sets the Course list used by the controllers to the Course repository
    public void setCourseList(ArrayList list){
        courseRepo.setCourse(list);
    }

//---------------------------
//ROOM Controllers
//---------------------------
    
    //This operation returns a list of all the Room with Room ID and Room Type
    public void viewAllRoom(){
        //Assigns the Room repository to a list
        ArrayList list = roomRepo.getAllRoom();
        for (int i = 0; i<list.size(); i++){
            //Assigns the records from the Room repo to a temporary object
            Room temp = (Room)list.get(i);
            System.out.print("Room details: \n Room ID: " + temp.getRoomID() + 
                    "\n Room Type: " + temp.getRoomType() + "\n");
        }
    }
    
    //This operation sets the Room list used by the controllers to the Room repository
    public void setRoomList(ArrayList list){
        roomRepo.setRoom(list);
    }

//---------------------------
//INSTRUCTOR Controllers
//---------------------------
    
    //
    public void viewAllInstructor(ArrayList<String> instructor_list){
        ArrayList list = instructorRepo.getAllInstructor();
        if (list.size() > 0){
            for (int i = 0; i<list.size(); i++){
                Instructor temp = (Instructor)list.get(i);
                instructor_list.add(temp.getInstructorID() + ": " + temp.getFirstname() + " " + temp.getLastname());
            }
        }
    }
    
    public void setInstructorList(ArrayList list){
        instructorRepo.setInstructor(list);
    }
    
//---------------------------
//DATE VERIFICATION Controllers
//---------------------------
    
    //
    public boolean dayOfTheWeek(String theStartDate, String theEndDate, String dayOfTheWeek){
        
        if(theStartDate == null || theEndDate == null){
                return false;
        }
        
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        sdf.setLenient(false);
        
        try {
            //if not valid, it will throw ParseException
            Date StartDate = sdf.parse(theStartDate);

            Date EndDate = sdf.parse(theEndDate);

            SimpleDateFormat simpleDateformat = new SimpleDateFormat("EEEE"); // the day of the week spelled out completely
            String StartDay = simpleDateformat.format(StartDate);
            String EndDay = simpleDateformat.format(EndDate);

            if (EndDay.equals(dayOfTheWeek) && StartDay.equals(dayOfTheWeek)) {
                return true;
            } else {
                return false;
            }
            
        } catch (ParseException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean isStartDateBeforeEndDate(String theStartDate, String theEndDate){

        if(theStartDate == null || theEndDate == null){
            return false;
        }
        
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        sdf.setLenient(false);
        
        try {
            //if not valid, it will throw ParseException
            Date StartDate = sdf.parse(theStartDate);

            Date EndDate = sdf.parse(theEndDate);

            if (StartDate.compareTo(EndDate) <= 0) {
                return true;
            } else {
                return false;
            }

        } catch (ParseException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public void generateDateList(String start_date, String end_date, ArrayList<String> dateList){
        dateList.add(start_date);
        String theCurDate = start_date;
        
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        sdf.setLenient(false);
        
        try {
            Date EndDate = sdf.parse(end_date);
            Date CurDate = sdf.parse(theCurDate);
            
            while ( CurDate.compareTo(EndDate) < 0 ){
                //if not valid, it will throw ParseException
                Calendar cal = Calendar.getInstance();
                cal.setTime(CurDate);
                cal.add(Calendar.DATE, 7); // add 10 days

                CurDate = cal.getTime();

                theCurDate = sdf.format(CurDate);
                dateList.add(theCurDate);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
}