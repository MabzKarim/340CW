/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stockcontrolsystem;
import java.sql.Connection;
import java.util.*;

/**
 *
 * @author Mabz
 */
//public class AddNewStockMediator {
    
    
    
    
    //public String eventMediator(Event e) {
        //String result = ""
        //if (e.event_type == SEARCH) {
            
            //if (check_StockitemID(),  matches("StockitemName", "StockitemPrice", "StockitemQuantity" + "StockitemArrival" + "StockitemMinimum" + "StockitemMaximum")) {
                //return "Item not found";
                
        //}
        
    //}
    
