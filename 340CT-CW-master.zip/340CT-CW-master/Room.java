package ts_gui;
/**
 *
 * @author karimm9
 */
public class Room {
    //Room Fields
    private int room_id = -1;
    private String room_type = "";

    //Returns Room Fields
    public int getRoomID(){
        return room_id;
    }
    public String getRoomType(){
        return room_type;
    }
   
    //Assigns Room Fields
    public void setRoomID(int aRef){
        room_id = aRef;
    }
    public void setRoomType(String aRoomType){
        room_type = aRoomType;
    }
}