# 340CT


SPRINT 1
- INCLUDES
USER STORY 1: “As a Stock Control Assistant, I want to be able to edit items within the system, so that I can ensure that the correct information is stored.”


SPRINT 2
- INCLUDES
USER STORY 2: “As a Store Manager, I want to be able to add items onto the system, so that I can increase the variety of stock.”


SPRINT 3
- INCLUDES
USER STORY 3: “As a Store Manager, I want to be able to Delete items from the system, so that I can ensure that the system is kept up to date by removing items that are no longer in demand”.
