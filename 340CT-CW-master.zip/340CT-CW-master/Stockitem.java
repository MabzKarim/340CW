package stockcontrolsystem;
/**
 *
 * @author karimm9
 */
public class Stockitem {
    //Stockitem Fields
    private int stockitem_id = -1;
    private String stockitem_name = "";
    private String stockitem_price = "";
    private int stockitem_quantity = -1;
    private String stockitem_arrival = "";
    private int stockitem_minimum = -1;
    private int stockitem_maximum = -1;


    //Returns Stockitem Fields
    public int getStockitemID(){
        return stockitem_id;
    }
    public String getStockitemName(){
        return stockitem_name;
    }
    public String getStockitemPrice(){
        return stockitem_price;
    }
    public int getStockitemQuantity(){
        return stockitem_quantity;
    }
    public String getStockitemArrival(){
        return stockitem_arrival;
    }
    public int getStockitemMinimum(){
        return stockitem_minimum;
    }
    public int getStockitemMaximum(){
        return stockitem_maximum;
    }
    
    
  
    //Assigns Stockitem Fields
    public void setStockitemID(int aRef){
        stockitem_id = aRef;
    }
    public void setStockitemName(String aStockitemName){
        stockitem_name = aStockitemName;
    }
    public void setStockitemPrice(String aStockitemPrice){
        stockitem_price = aStockitemPrice;
    }
    public void setStockitemQuantity(int aRef){
        stockitem_quantity = aRef;
    }
    public void setStockitemArrival(String aStockitemArrival){
        stockitem_arrival = aStockitemArrival;
    }
    public void setStockitemMinimum(int aRef){
        stockitem_minimum = aRef;
    }
    public void setStockitemMaximum(int aRef){
        stockitem_maximum = aRef;
    }
}
