/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stockcontrolsystem;

import java.sql.Connection;
import java.util.ArrayList;

/**
 *
 * @author Mabz
 */



public class ItemProccessor {
    
    //Declares all the data repositories
    StockitemRepoImpl StockitemRepo = new StockitemRepoImpl();

    
    public void setItemList(ArrayList list){
        StockitemRepo.setStockitem(list);
    }
    
    //methods
    public void add_item(String stockitem_name, String stockitem_price, int stockitem_quantity, String stockitem_arrival, int stockitem_minimum, int stockitem_maximum, Connection conn){
        ArrayList Stockitem_list = StockitemRepo.getAllStockitem();
        int i = 0;
        
        Stockitem temp = new Stockitem();
        temp.setStockitemID(Stockitem_list.size() + 1);
        temp.setStockitemName(stockitem_name);
        temp.setStockitemPrice(stockitem_price);
        temp.setStockitemQuantity(stockitem_quantity);
        temp.setStockitemArrival(stockitem_arrival);
        temp.setStockitemMinimum(stockitem_minimum);
        temp.setStockitemMaximum(stockitem_maximum);
        StockitemRepo.addStockitem(temp, conn);
    }
    
    public Stockitem view_item(int ref){
        //Assigns the repository to a list
        ArrayList Stockitem_list = StockitemRepo.getAllStockitem();
        boolean found = false;
        int i = 0;
        //Iterates through the Course repository list until th record specified by ID is found
        while (i<Stockitem_list.size() && !found){
            Stockitem temp = (Stockitem)Stockitem_list.get(i);
            if (ref == temp.getStockitemID()){
                //Assigns the record from the repo to a temporary object
                System.out.print("Item Details: \n Item ID: " +
                        ref + "\n Item Name: " +
                        temp.getStockitemName() + "\n Item Price: " +
                        temp.getStockitemPrice() + "\n");
                
                found = true;
                //Returns the temporary object
                return temp;
            }
        i++;    
        }
        return null;
    }
    
    public void edit_item(int ref, String stockitem_name, String stockitem_price, int stockitem_quantity, String stockitem_arrival, int stockitem_minimum, int stockitem_maximum, Connection conn){
        ArrayList Stockitem_list = StockitemRepo.getAllStockitem();
        boolean found  = false;
        int i = 0;
        while (i<Stockitem_list.size() && !found){
            Stockitem temp = (Stockitem)Stockitem_list.get(i);
            if (ref == temp.getStockitemID()){
                temp.setStockitemName(stockitem_name);
                temp.setStockitemPrice(stockitem_price);
                temp.setStockitemQuantity(stockitem_quantity);
                temp.setStockitemArrival(stockitem_arrival);
                temp.setStockitemMinimum(stockitem_minimum);
                temp.setStockitemMaximum(stockitem_maximum);
                StockitemRepo.editStockitem(temp, conn);
                found = true;
            }
        i++;
        }
    }
    
    public void delete_item(int ref, Connection conn){
            Stockitem dentist = new Stockitem();
            dentist.setStockitemID(ref);
         
            StockitemRepo.deleteStockitem(dentist, conn);

    }
   
    }
    
        

        

    
    


