package ts_gui;

import java.sql.*;
import java.util.ArrayList;
/**
 *
 * @author karimm9
 */
public interface CourseRepo {
    //Define all the course operations for course table
    public void addCourse(Course cou, Connection conn);
    public Course getCourse(Course course);
    public ArrayList<Course> getAllCourse();
    public void setCourse(ArrayList course_list);    
    public ArrayList read(Connection conn);
    void write(Connection conn, String str, Course course);
    
}