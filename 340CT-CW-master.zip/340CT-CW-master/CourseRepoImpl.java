package ts_gui;

import java.sql.*;
import java.util.ArrayList;
/**
 *
 * @author karimm9
 */
public class CourseRepoImpl implements CourseRepo {
    //Defines all the Course Data Attricutes & Operations
    private ArrayList<Course> courses;
    
    public CourseRepoImpl(){
        courses = new ArrayList<>();
    }
    
    public CourseRepoImpl(ArrayList course_list){
        courses = course_list;
    }
    
    @Override
    public void addCourse(Course course, Connection conn){
        courses.add(course); 
        write(conn,  "add",  course);
    }
    
    @Override
    public Course getCourse(Course course){
        return courses.get(course.getCourseID());
    }
    
    @Override
    public ArrayList<Course> getAllCourse(){
        return courses;
    }
    
    @Override
    public void setCourse(ArrayList course_list){
        courses = course_list;
    }
    
    @Override
    public ArrayList read(Connection conn){
        //This operation will read all the Course records from the COURSE TABLE
        System.out.println("Reading from the COURSE_TABLE... ");
        //Defines the Course List which wil store all the course records from the COURSE TABLE
        ArrayList course_list = new ArrayList();
        try {
            //Defines and execute the SQL statement to be executed - Select all the courses from the course table            
            Statement st = conn.createStatement();
            ResultSet rs=null;
            String sql = "SELECT * FROM COURSE_TABLE";
            rs=st.executeQuery(sql);
            
            while(rs.next()){
                //Assigns all the Course attributes to the Course objects
                Course cou = new Course();
                cou.setCourseID(rs.getInt("COURSE_ID"));
                cou.setCourseName(rs.getString("COURSE_NAME"));
                cou.setCourseLength(rs.getInt("COURSE_LENGTH"));
                //Appends the Course objects to the Course list
                course_list.add(cou);
                System.out.println(rs.getInt("COURSE_ID")+"\t"+rs.getString("COURSE_NAME")+"\t"+rs.getInt("COURSE_LENGTH"));
            }
            //Closes the ResultsSet & Statement objects used.
            rs.close();
            st.close();

        } catch (SQLException ex) {
            System.out.println("SQLException failed !");
        } 
        //Assigns the Course list to the course data object
        courses = course_list;
        System.out.println("Number of Courses: " + course_list.size());
        
        return courses;
    }
    
    public void write(Connection conn, String str, Course course){
        //This operation will write to the COURSE TABLE
        //Calls operation getAllCourse operation to assign all the course records to the course list
        ArrayList course_list = getAllCourse();
        System.out.println("Writing to the COURSE_TABLE... ");
        
        if (str.equals("add")){
            try {
                //Defines and creates the SQL statement to add a new Course records
                Statement st = conn.createStatement();
                String sql = "INSERT INTO COURSE_TABLE VALUES (" + course.getCourseID() + ", '" + course.getCourseName() + ", '" + course.getCourseLength() + "')";
                //Executes the SQL statement
                st.executeUpdate(sql);
                //Closes the statement object used
                st.close();
            }
            catch (SQLException ex) {
                    System.out.println("SQLException error ");
            }
        }
    }
}