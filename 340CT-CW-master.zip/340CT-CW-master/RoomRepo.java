package ts_gui;

import java.sql.*;
import java.util.ArrayList;
/**
 *
 * @author karimm9
 */
public interface RoomRepo {
    //Define all the room operations for room table
    public void addRoom(Room roo, Connection conn);
    public Room getRoom(Room room);
    public ArrayList<Room> getAllRoom();
    public void setRoom(ArrayList list);    
    public ArrayList read(Connection conn);
    void write(Connection conn, String str, Room room);

}