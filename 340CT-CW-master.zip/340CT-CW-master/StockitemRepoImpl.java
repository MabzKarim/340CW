package stockcontrolsystem;

import java.sql.*;
import java.util.ArrayList;
/**
 *
 * @author karimm9
 */
public class StockitemRepoImpl implements StockitemRepo {
    //Defines all the Stockitem Data Attricutes & Operations
    private ArrayList<Stockitem> stockitems;
    
    public StockitemRepoImpl(){
        stockitems = new ArrayList<>();
    }
    
    public StockitemRepoImpl(ArrayList stockitem_list){
        stockitems = stockitem_list;
    }
    
    @Override
    public void addStockitem(Stockitem stockitem, Connection conn){
        stockitems.add(stockitem); 
        write(conn,  "add",  stockitem);
    }
    
    @Override
    public Stockitem getStockitem(Stockitem stockitem){
        return stockitems.get(stockitem.getStockitemID());
    }
    
    @Override
    public ArrayList<Stockitem> getAllStockitem(){
        return stockitems;
    }
    
    @Override
    public void setStockitem(ArrayList stockitem_list){
        stockitems = stockitem_list;
    }
    
    public void editStockitem(Stockitem stockitem, Connection conn){
            ArrayList Stockitem_list = getAllStockitem();
            boolean found = false;
            int i = 0;
            while ((!found) && (i<Stockitem_list.size())) {
                Stockitem temp = (Stockitem)Stockitem_list.get(i);
                if (stockitem.getStockitemID() == temp.getStockitemID()){
                    
                    temp.setStockitemName(stockitem.getStockitemName());
                    temp.setStockitemPrice(stockitem.getStockitemPrice());
                    temp.setStockitemQuantity(stockitem.getStockitemQuantity());
                    temp.setStockitemArrival(stockitem.getStockitemArrival());
                    temp.setStockitemMinimum(stockitem.getStockitemMinimum());
                    temp.setStockitemMaximum(stockitem.getStockitemMaximum());
                    
                    
                    found = true;
                }
                i++;
            }
            
            write(conn,  "Edit",  stockitem);

    }
    
        public void deleteStockitem(Stockitem stockitem, Connection conn){ 

            ArrayList Stockitem_list = getAllStockitem(); 
            ArrayList tempList = new ArrayList();
            
            for (int i = 0; i<Stockitem_list.size(); i++) {
                Stockitem temp = (Stockitem)Stockitem_list.get(i);
                if (stockitem.getStockitemID() != temp.getStockitemID()){
                    tempList.add(temp);    
                }
            }
            setStockitem(tempList);
            
            write(conn,  "delete",  stockitem);

    }
    
    @Override
    public ArrayList read(Connection conn){
        //This operation will read all the Stockitem records from the STOCKITEM TABLE
        System.out.println("Reading from the STOCKITEM_TABLE... ");
        //Defines the Stockitem List which wil store all the stockitem records from the STOCKITEM TABLE
        ArrayList stockitem_list = new ArrayList();
        try {
            //Defines and execute the SQL statement to be executed - Select all the stockitems from the stockitem table            
            Statement st = conn.createStatement();
            ResultSet rs=null;
            String sql = "SELECT * FROM STOCKITEM_TABLE";
            rs=st.executeQuery(sql);
            
            while(rs.next()){
                //Assigns all the Stockitem attributes to the Stockitem objects
                Stockitem stk = new Stockitem();
                stk.setStockitemID(rs.getInt("STOCKITEM_ID"));
                stk.setStockitemName(rs.getString("STOCKITEM_NAME"));
                stk.setStockitemPrice(rs.getString("STOCKITEM_PRICE"));
                stk.setStockitemQuantity(rs.getInt("STOCKITEM_Quantity"));
                stk.setStockitemArrival(rs.getString("STOCKITEM_ARRIVAL"));
                stk.setStockitemMinimum(rs.getInt("STOCKITEM_MINIMUM"));
                stk.setStockitemMaximum(rs.getInt("STOCKITEM_MAXIMUM"));
                //Appends the Stockitem objects to the Stockitem list
                stockitem_list.add(stk);
                System.out.println(rs.getInt("STOCKITEM_ID")+"\t"
                        +rs.getString("STOCKITEM_NAME")+"\t"
                        +rs.getString("STOCKITEM_PRICE")+"\t"
                        +rs.getInt("STOCKITEM_QUANTITY")+"\t"
                        +rs.getString("STOCKITEM_ARRIVAL")+"\t"
                        +rs.getInt("STOCKITEM_MINIMUM")+"\t"
                        +rs.getInt("STOCKITEM_MAXIMUM"));
            }
            //Closes the ResultsSet & Statement objects used.
            rs.close();
            st.close();

        } catch (SQLException ex) {
            System.out.println("SQLException failed !");
        } 
        //Assigns the Stockitem list to the stockitem data object
        stockitems = stockitem_list;
        System.out.println("Number of Stockitems: " + stockitem_list.size());
        
        return stockitems;
    }
    
    public void write(Connection conn, String str, Stockitem stockitem){
        //This operation will write to the STAFF TABLE
        //Calls operation getAllStockitem operation to assign all the stockitem records to the stockitem list
        ArrayList stockitem_list = getAllStockitem();
        System.out.println("Writing to the STOCKITEM_TABLE... ");
        
        if (str.equals("add")){
            try {
                //Defines and creates the SQL statement to add a new Stockitem records
                Statement st = conn.createStatement();
                String sql = "INSERT INTO STOCKITEM_TABLE VALUES (" + stockitem.getStockitemID()
                        + ", '" + stockitem.getStockitemName()
                        + "', '" + stockitem.getStockitemPrice()
                        + "', " + stockitem.getStockitemQuantity()
                        + ", '" + stockitem.getStockitemArrival()
                        + "', " + stockitem.getStockitemMinimum()
                        + ", " + stockitem.getStockitemMaximum() + ")";
                //Executes the SQL statement
                st.executeUpdate(sql);
                //Closes the statement object used
                st.close();
            }
            catch (SQLException ex) {
                    System.out.println("SQLException error ");
            }
        }
        else if (str.equals("delete")) {
            try {   
                    Statement st = conn.createStatement();
              
                    String sql = "DELETE FROM STOCKITEM_TABLE WHERE STOCKITEM_ID = " + stockitem.getStockitemID()+ " ";
                    st.executeUpdate(sql);

                    st.close();
            }
            catch (SQLException ex) {
                    System.out.println("SQLException error ");
            }                             
        }

    }
}