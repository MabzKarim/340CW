package ts_gui;

import java.sql.*;
import java.util.ArrayList;
/**
 *
 * @author karimm9
 */
public interface SessionRepo {
    //Define all the session operations for session table
    public void addSession(Session sess, Connection conn);
    public Session getSession(Session session);
    public ArrayList<Session> getAllSession();
    public void setSession(ArrayList list);    
    public ArrayList read(Connection conn);
    void write(Connection conn, String str, Session session);

}