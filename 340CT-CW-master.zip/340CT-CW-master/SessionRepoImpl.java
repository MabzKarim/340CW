/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ts_gui;
import java.sql.*;
import java.util.ArrayList;
/**
 *
 * @author karimm9
 */
public class SessionRepoImpl implements SessionRepo {
    //Defines all the Session Data Attricutes & Operations
    private ArrayList<Session> sessions;
    
    public SessionRepoImpl(){
        sessions = new ArrayList<>();
    }
    
    public SessionRepoImpl(ArrayList list){
        sessions = list;
    }
    
    @Override
    public void addSession(Session session, Connection conn){
        sessions.add(session); 
        write(conn,  "add",  session);
    }
    
    @Override
    public Session getSession(Session session){
        return sessions.get(session.getSessionID());
    }
    
    @Override
    public ArrayList<Session> getAllSession(){
        return sessions;
    }
    
    @Override
    public void setSession(ArrayList list){
        sessions = list;
    }
    
    @Override
    public ArrayList read(Connection conn){
        //This operation will read all the Session records from the SESSION_TABLE
        System.out.println("Reading from the SESSION_TABLE... ");
        //Defines the Session List which wil store all the Session records from the SESSION_TABLE
        ArrayList list = new ArrayList();
        try {   
            //Defines and execute the SQL statement to be executed - Select all the Session from the SESSION_TABLE
            Statement st = conn.createStatement();
            ResultSet rs=null;
            String sql = "SELECT * FROM SESSION_TABLE";
            rs=st.executeQuery(sql);

            while(rs.next()){
                //Assigns all the Session attributes to the Session objects
                Session sess = new Session();
                sess.setSessionID(rs.getInt("SESSION_ID"));
                sess.setCourseID(rs.getInt("COURSE_ID"));
                sess.setRoomID(rs.getInt("ROOM_ID"));
                sess.setInstructorID(rs.getInt("INSTRUCTOR_ID"));
                sess.setDate(rs.getString("DATE"));
                sess.setTime(rs.getInt("TIME"));
                //Appends the Session objects to the Session list
                list.add(sess);
                System.out.println(rs.getInt("SESSION_ID")+"\t"+
                                   rs.getInt("COURSE_ID")+"\t"+
                                   rs.getInt("ROOM_ID")+"\t"+
                                   rs.getInt("INSTRUCTOR_ID")+"\t"+
                                   rs.getString("DATE")+"\t"+
                                   rs.getInt("TIME"));
            }
            //Closes the ResultsSet & Statement objects used.
            rs.close();
            st.close();

        } catch (SQLException ex) {
            System.out.println("SQLException failed ! ");
        } 
        //Assigns the Session list to the Session data object
        sessions = list;
        System.out.println("session..." + list.size());
        
        return sessions;
    }
    
    @Override
    public void write(Connection conn, String str, Session session){
        //This operation will write to the SESSION_TABLE
        //Calls operation getAllSessions operation to assign all the Session records to the Session list
        ArrayList list = getAllSession();
        System.out.println("Writing to the database... ");
        if (str.equals("add")){
            try {
                //Defines and creates the SQL statement to add a new Session records
                Statement st = conn.createStatement();
                String sql = "INSERT INTO SESSION_TABLE VALUES (" + session.getSessionID() + ", " + session.getCourseID() + " , " + session.getRoomID() + ", " + session.getInstructorID() + ", '" + session.getDate() + "', " + session.getTime() + ")";
                //Executes the SQL statement
                st.executeUpdate(sql);
                //Closes the statement object used
                st.close();
            }
            catch (SQLException ex) {
                System.out.println("SQLException error 1:" + ex);
            }
        }
    }
}