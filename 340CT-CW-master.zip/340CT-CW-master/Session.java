package ts_gui;
/**
 *
 * @author karimm9
 */
public class Session {
    //Session Fields
    private int session_id = -1;
    private int course_id = -1;
    private int room_id = -1;
    private int instructor_id = -1;
    private String date = "";
    private int time = -1;

    //Returns Session Fields
    public int getSessionID(){
        return session_id;
    }
    public int getCourseID(){
        return course_id;
    }
    public int getRoomID(){
        return room_id;
    }
    public int getInstructorID(){
        return instructor_id;
    }
    public String getDate(){
        return date;
    }
    public int getTime(){
        return time;
    }

    //Assigns Session Fields
    public void setSessionID(int aRef){
        session_id = aRef;
    }
    public void setCourseID(int aRef){
        course_id = aRef;
    }
    public void setRoomID(int aRef){
        room_id = aRef;
    }
    public void setInstructorID(int aRef){
        instructor_id = aRef;
    }
    public void setDate(String aDate){
        date = aDate;
    }
    public void setTime(int aRef){
        time = aRef;
    }
}