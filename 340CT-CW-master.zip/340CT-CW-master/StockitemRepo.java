package stockcontrolsystem;

import java.sql.*;
import java.util.ArrayList;
/**
 *
 * @author karimm9
 */
public interface StockitemRepo {
    //Define all the stockitem operations for stockitem table
    public void addStockitem(Stockitem stk, Connection conn);
    public Stockitem getStockitem(Stockitem stockitem);
    public ArrayList<Stockitem> getAllStockitem();
    public void setStockitem(ArrayList stockitem_list);
    public void deleteStockitem (Stockitem itm, Connection conn);
    public void editStockitem (Stockitem itm, Connection conn);
    public ArrayList read(Connection conn);
    void write(Connection conn, String str, Stockitem stockitem);
    
}