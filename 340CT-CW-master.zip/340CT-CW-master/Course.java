package ts_gui;
/**
 *
 * @author karimm9
 */
public class Course {
    //Course Fields
    private int course_id = -1;
    private String course_name = "";
    private int course_length = -1;

    //Returns Course Fields
    public int getCourseID(){
        return course_id;
    }
    public String getCourseName(){
        return course_name;
    }
    public int getCourseLength(){
        return course_length;
    }
    
    //Assigns Course Fields
    public void setCourseID(int aRef){
        course_id = aRef;
    }
    public void setCourseName(String aCourseName){
        course_name = aCourseName;
    }
    public void setCourseLength(int aRef){
        course_length = aRef;
    }
}
