package stockcontrolsystem;

import java.sql.*;
import java.util.ArrayList;
/**
 *
 * @author karimm9
 */
public interface StaffRepo {
    //Define all the staff operations for staff table
    public void addStaff(Staff sta, Connection conn);
    public Staff getStaff(Staff staff);
    public ArrayList<Staff> getAllStaff();
    public void setStaff(ArrayList staff_list);    
    public ArrayList read(Connection conn);
    void write(Connection conn, String str, Staff staff);
    
}