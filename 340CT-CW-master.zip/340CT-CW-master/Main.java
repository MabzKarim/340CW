package ts_gui;

import java.sql.* ;
import java.util.*;

/**
 *
 * @author karimm9
 */

public class Main {

    /**
     * @param args the command line arguments
     */

    public static void main(String[] args){
        //Define all the different data persistent objects
        SessionRepoImpl sessionRepo = new SessionRepoImpl();
        CourseRepoImpl courseRepo = new CourseRepoImpl();
        RoomRepoImpl roomRepo = new RoomRepoImpl();
        InstructorRepoImpl instructorRepo = new InstructorRepoImpl();

        //Define SQL connection variables            
        String connectionURL = "jdbc:derby://localhost:1527/stockDB";
        String uName = "karimm9";
        String uPass= "Password1";

        try {
            //Attempt connection to the SQL database
            Connection conn = DriverManager.getConnection(connectionURL, uName, uPass);
            System.out.println("Connecting to ts_database..."); 

            if (conn != null){
                //Define and populate all the list used to store all the data from the ts_database
                ArrayList list = sessionRepo.read(conn);
                ArrayList course_list = courseRepo.read(conn);
                ArrayList room_list = roomRepo.read(conn);
                ArrayList instructor_list = instructorRepo.read(conn);

                //Call OfficerDemo operatoin which will load up the GUI
                OfficerGUI officerDemo = new OfficerGUI(conn, list, course_list, room_list, instructor_list);  
                officerDemo.showEventDemo();

            } else {
                System.out.println("null");  
            }

        } catch (SQLException ex) {
            System.out.println("Connection failed: " + ex);
        }
    } 
}