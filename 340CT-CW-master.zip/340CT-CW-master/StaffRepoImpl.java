package stockcontrolsystem;

import java.sql.*;
import java.util.ArrayList;
/**
 *
 * @author karimm9
 */
public class StaffRepoImpl implements StaffRepo {
    //Defines all the Staff Data Attricutes & Operations
    private ArrayList<Staff> staffs;
    
    public StaffRepoImpl(){
        staffs = new ArrayList<>();
    }
    
    public StaffRepoImpl(ArrayList staff_list){
        staffs = staff_list;
    }
    
    @Override
    public void addStaff(Staff staff, Connection conn){
        staffs.add(staff); 
        write(conn,  "add",  staff);
    }
    
    @Override
    public Staff getStaff(Staff staff){
        return staffs.get(staff.getUserID());
    }
    
    @Override
    public ArrayList<Staff> getAllStaff(){
        return staffs;
    }
    
    @Override
    public void setStaff(ArrayList staff_list){
        staffs = staff_list;
    }
    
    @Override
    public ArrayList read(Connection conn){
        //This operation will read all the Staff records from the STAFF TABLE
        System.out.println("Reading from the STAFF_TABLE... ");
        //Defines the Staff List which wil store all the staff records from the STAFF TABLE
        ArrayList staff_list = new ArrayList();
        try {
            //Defines and execute the SQL statement to be executed - Select all the staffs from the staff table            
            Statement st = conn.createStatement();
            ResultSet rs=null;
            String sql = "SELECT * FROM STAFF_TABLE";
            rs=st.executeQuery(sql);
            
            while(rs.next()){
                //Assigns all the Staff attributes to the Staff objects
                Staff sta = new Staff();
                sta.setUserID(rs.getInt("USER_ID"));
                sta.setPassword(rs.getString("PASSWORD"));
                sta.setFirstname(rs.getString("FIRST_NAME"));
                sta.setLastname(rs.getString("LAST_NAME"));
                sta.setStaffLevel(rs.getInt("STAFF_LEVEL"));
                //Appends the Staff objects to the Staff list
                staff_list.add(sta);
                System.out.println(rs.getInt("USER_ID")+"\t"
                        +rs.getString("PASSWORD")+"\t"
                        +rs.getString("FIRST_NAME")+"\t"
                        +rs.getString("LAST_NAME")+"\t"
                        +rs.getInt("STAFF_LEVEL"));
            }
            //Closes the ResultsSet & Statement objects used.
            rs.close();
            st.close();

        } catch (SQLException ex) {
            System.out.println("SQLException failed !");
        } 
        //Assigns the Staff list to the staff data object
        staffs = staff_list;
        System.out.println("Number of Staffs: " + staff_list.size());
        
        return staffs;
    }
    
    public void write(Connection conn, String str, Staff staff){
        //This operation will write to the STAFF TABLE
        //Calls operation getAllStaff operation to assign all the staff records to the staff list
        ArrayList staff_list = getAllStaff();
        System.out.println("Writing to the STAFF_TABLE... ");
        
        if (str.equals("add")){
            try {
                //Defines and creates the SQL statement to add a new Staff records
                Statement st = conn.createStatement();
                String sql = "INSERT INTO STAFF_TABLE VALUES (" + staff.getUserID() 
                        + ", '" + staff.getPassword()
                        + "', '" + staff.getFirstname() 
                        + "', '" + staff.getLastname() 
                        + "', '" + staff.getStaffLevel() + "')";
                
                //Executes the SQL statement
                st.executeUpdate(sql);
                //Closes the statement object used
                st.close();
            }
            catch (SQLException ex) {
                    System.out.println("SQLException error ");
            }
        }
    }
}