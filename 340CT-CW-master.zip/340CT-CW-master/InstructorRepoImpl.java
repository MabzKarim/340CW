/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ts_gui;

import java.sql.*;
import java.util.ArrayList;
/**
 *
 * @author karimm9
 */
public class InstructorRepoImpl implements InstructorRepo {
    //Defines all the Instructor Data Attricutes & Operations
    private ArrayList<Instructor> instructors;
    
    public InstructorRepoImpl(){
        instructors = new ArrayList<>();
    }
    
    public InstructorRepoImpl(ArrayList list){
        instructors = list;
    }
    
    @Override
    public void addInstructor(Instructor instructor, Connection conn){
        instructors.add(instructor); 
        write(conn,  "add",  instructor);
    }
    
    @Override
    public Instructor getInstructor(Instructor instructor){
        return instructors.get(instructor.getInstructorID());
    }
    
    @Override
    public ArrayList<Instructor> getAllInstructor(){
        return instructors;
    }
    
    @Override
    public void setInstructor(ArrayList list){
        instructors = list;
    }
    
    @Override
    public ArrayList read(Connection conn){
        //This operation will read all the Instructor records from the INSTRUCTOR TABLE
        System.out.println("Reading from the INSTRUCTOR_TABLE... ");
        //Defines the Instructor List which wil store all the Instructor records from the INSTRUCTOR_TABLE TABLE
        ArrayList list = new ArrayList();
        try {   
            //Defines and execute the SQL statement to be executed - Select all the Instructors from the INSTRUCTOR TABLE
            Statement st = conn.createStatement();
            ResultSet rs=null;
            String sql = "SELECT * FROM INSTRUCTOR_TABLE";
            rs=st.executeQuery(sql);

            while(rs.next()){
                //Assigns all the Instructor attributes to the Instructor objects
                Instructor instr = new Instructor();
                instr.setInstructorID(rs.getInt("INSTRUCTOR_ID"));
                instr.setFirstname(rs.getString("FIRSTNAME"));
                instr.setLastname(rs.getString("LASTNAME"));
                instr.setDOB(rs.getString("DOB"));
                instr.setEmailAddress(rs.getString("EMAIL_ADDRESS"));
                //Appends the Instructor objects to the Instructor list
                list.add(instr);
                System.out.println(rs.getInt("INSTRUCTOR_ID")+"\t"+rs.getString("FIRSTNAME")+"\t"+rs.getString("LASTNAME")+"\t"+rs.getString("DOB")+"\t"+rs.getString("EMAIL_ADDRESS"));
            }
            //Closes the ResultsSet & Statement objects used.
            rs.close();
            st.close();
                
        } catch (SQLException ex) {
            System.out.println("SQLException failed ! ");
        } 
        
        //Assigns the Instructor list to the Instructor data object
        instructors = list;
        System.out.println("instructor..." + list.size());
        
        return instructors;
    }
    
    @Override
    public void write(Connection conn, String str, Instructor instructor){
        //This operation will write to the INSTRUCTOR TABLE
        //Calls operation getAllInstructors operation to assign all the Instructor records to the Instructor list
        ArrayList list = getAllInstructor();
        System.out.println("Writing to the INSTRUCTOR_TABLE... ");
        
        if (str.equals("add")){
            try {
                //Defines and creates the SQL statement to add a new Instructor records
                Statement st = conn.createStatement();
                String sql = "INSERT INTO INSTRUCTOR_TABLE VALUES (" + instructor.getInstructorID() + ", '" + instructor.getFirstname() + ", '" + instructor.getLastname() + ", '" + instructor.getDOB() + ", '" + instructor.getEmailAddress() + "')";
                //Executes the SQL statement
                st.executeUpdate(sql);
                //Closes the statement object used
                st.close();
            }
            catch (SQLException ex) {
                System.out.println("SQLException error ");
            } 
        }
    }
}