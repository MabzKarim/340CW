package ts_gui;
/**
 *
 * @author karimm9
 */
public class Instructor {
    //Instructor Fields
    private int instructor_id = -1;
    private String firstname = "";
    private String lastname = "";
    private String dob = "";
    private String email_address = "";

    //Returns Instructor Fields
    public int getInstructorID(){
        return instructor_id;
    }
    public String getFirstname(){
        return firstname;
    }
    public String getLastname(){
        return lastname;
    }
    public String getDOB(){
        return dob;
    }
    public String getEmailAddress(){
        return email_address;
    }
    
    //Assigns Instructor Fields
    public void setInstructorID(int aRef){
        instructor_id = aRef;
    }
    public void setFirstname(String aFirstname){
        firstname = aFirstname;
    }
    public void setLastname(String aLastname){
        lastname = aLastname;
    }
    public void setDOB(String aDOB){
        dob = aDOB;
    }
    public void setEmailAddress(String aEmail){
        email_address = aEmail;
    }
}