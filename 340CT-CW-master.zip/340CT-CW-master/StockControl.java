/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stockcontrolsystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Mabz
 */
public class StockControl {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {//Define all the different data persistent objects
        StaffRepoImpl StaffRepo = new StaffRepoImpl();
        StockitemRepoImpl StockitemRepo = new StockitemRepoImpl();

        //Define SQL connection variables            
        String connectionURL = "jdbc:derby://localhost:1527/stockDB";
        String uName = "karimm9";
        String uPass= "Password1";

        try {
            //Attempt connection to the SQL database
            Connection conn = DriverManager.getConnection(connectionURL, uName, uPass);
            System.out.println("Connecting to stockDB..."); 

            if (conn != null){
                //Define and populate all the list used to store all the data from the StockDB
                ArrayList staff_list = StaffRepo.read(conn);
                ArrayList Stockitem_list = StockitemRepo.read(conn);

                //Call EditDemo operatoin which will load up the GUI
                ViewGUI EditDemo = new ViewGUI(conn, staff_list, Stockitem_list);  
                EditDemo.setVisible(true);

            } else {
                System.out.println("null");  
            }

        } catch (SQLException ex) {
            System.out.println("Connection failed: " + ex);
        }
    } 
}
        // TODO code application logic here
    
    

