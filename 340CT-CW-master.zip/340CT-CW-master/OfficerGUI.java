/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ts_gui;
/**
 *
 * @author karimm9
 */
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.sql.Connection;
import javax.swing.JButton;
import javax.swing.*;
import javax.swing.border.TitledBorder;

public class OfficerGUI {
    /**
     * @param args the command line arguments
     */   
        
    private JFrame mainFrame = new JFrame("Smart-IT Timetabling System");
    private JFrame addFrame = new JFrame("Register Sessions : Smart-IT Timetabling System");
    
    private JPanel mainPanel;
    private JPanel mainAddPanel;
    private JPanel searchPanel;
    private JPanel sessionPanel;
    
    final static boolean shouldFill = true;
    final static boolean shouldWeightX = true;
    final static boolean RIGHT_TO_LEFT = false;
    
    OfficerController con = new OfficerController(); 
    
    ArrayList list = new ArrayList();
    ArrayList course_list = new ArrayList();
    ArrayList instructor_list = new ArrayList();
    ArrayList room_list = new ArrayList();
    
    Connection conn;    
    
    public OfficerGUI(Connection aConn, ArrayList aList, ArrayList aCourseList, ArrayList aRoomList, ArrayList aInstructorList) {
        conn = aConn;
        con.setSessionList(aList);
        con.setCourseList(aCourseList);
        con.setInstructorList(aInstructorList);
        con.setRoomList(aRoomList);
    }

    public void menu_setup(){
        mainFrame = new JFrame("Smart-IT Timetabling System");
        mainFrame.setSize(700, 350);
        mainFrame.setResizable(false);

        mainFrame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent windowEvent){
                System.exit(0);
            }
        });    
        
        TitledBorder mainHeader = new TitledBorder("Smart-IT Timetabling System");
        mainHeader.setTitleJustification(TitledBorder.CENTER);
        mainHeader.setTitlePosition(TitledBorder.TOP);
        
        mainPanel = new JPanel();
        mainPanel.setLayout(new GridLayout(2, 2, 10, 10));
        mainPanel.setBorder(mainHeader);

        mainFrame.add(mainPanel); 
        mainFrame.setLocationRelativeTo(mainPanel);
        mainFrame.setVisible(true);  
    }
    
    public void add_setup(JFrame frame){
        frame.setSize(700, 350);
        frame.setLocationRelativeTo(mainAddPanel);
        frame.setResizable(false);
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent windowEvent){
	        System.exit(0);
            }        
        });    
        
        mainAddPanel = new JPanel();
        mainAddPanel.setLayout(new GridLayout(0,2));
        
        TitledBorder sessionsBorder = new TitledBorder("Available Sessions");
        sessionsBorder.setTitleJustification(TitledBorder.CENTER);
        sessionsBorder.setTitlePosition(TitledBorder.TOP);
        sessionPanel = new JPanel();
        sessionPanel.setLayout(new GridBagLayout());
        sessionPanel.setBorder(sessionsBorder);
        
        TitledBorder searchBorder = new TitledBorder("Search For Sessions");
        searchBorder.setTitleJustification(TitledBorder.CENTER);
        searchBorder.setTitlePosition(TitledBorder.TOP);
        searchPanel = new JPanel();
        searchPanel.setLayout(new GridLayout(0,2,7,7));
        searchPanel.setBorder(searchBorder);
        
        mainAddPanel.add(searchPanel);
        mainAddPanel.add(sessionPanel);
        frame.add(mainAddPanel);     
        frame.setVisible(true);
    }

    private void setVisibility(JFrame frame, boolean bool){
        frame.setVisible(bool); 
    }

    public void showEventDemo(){
        menu_setup(); 

        JButton addButton = new JButton("Add a session");
        JButton viewButton = new JButton("View all sessions");
        JButton updateButton = new JButton("Update a session");
        JButton deletelButton = new JButton("Delete a session");

        addButton.setActionCommand("Add a session");
        viewButton.setActionCommand("View all sessions");
        updateButton.setActionCommand("Update a session");
        deletelButton.setActionCommand("Delete a session");

        addButton.addActionListener(new ButtonClickListener()); 
        viewButton.addActionListener(new ButtonClickListener());
        updateButton.addActionListener(new ButtonClickListener()); 
        deletelButton.addActionListener(new ButtonClickListener()); 

        mainPanel.add(addButton);
        mainPanel.add(viewButton);
        mainPanel.add(updateButton);
        mainPanel.add(deletelButton);       

        mainFrame.setVisible(true);
        addFrame.setVisible(false);

    }

    private class ButtonClickListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            String command = e.getActionCommand();  
            switch (command) {
                case "Add a session":
                    addDemo();
                    break;
                case "View all sessions":
                    JOptionPane.showMessageDialog(mainFrame, "View All Sessions Button Clicked", "View All Sessions Button Clicked",JOptionPane.INFORMATION_MESSAGE);
                    break;
                case "Update a session":
                    JOptionPane.showMessageDialog(mainFrame, "Update Session Button Clicked", "Update Session Button Clicked",JOptionPane.INFORMATION_MESSAGE);
                    break;
                default:
                    JOptionPane.showMessageDialog(mainFrame, "Delete Button Clicked", "Delete Button Clicked",JOptionPane.INFORMATION_MESSAGE);
                    break;
            }
        }
    }
      
    public void addDemo(){
        mainFrame.setVisible(false);
        JFrame addFrame = new JFrame("Register Sessions : Smart-IT Timetabling System");
        add_setup(addFrame);
     
        JLabel  CourseLabel= new JLabel("Select Course: ", JLabel.CENTER);
        JLabel  InstructorLabel = new JLabel("Select Instructor: ", JLabel.CENTER);
        JLabel  DayLabel = new JLabel("Select the Day: ", JLabel.CENTER);
        JLabel  StartDateLabel = new JLabel("Enter the Start Date: ", JLabel.CENTER);
        JLabel  EndDateLabel = new JLabel("Enter the End Date: ", JLabel.CENTER);

        ///
        ArrayList<String> list_course = new ArrayList<>();
        con.viewAllCourse(list_course);

        final JComboBox courseList = new JComboBox();
        
        for (int i = 0; i<list_course.size(); i++){
            courseList.addItem(list_course.get(i));
        }
        courseList.setSelectedIndex(0);   

        ///
        ArrayList<String> list_instructor = new ArrayList<>();
        con.viewAllInstructor(list_instructor);

        final JComboBox instructorList = new JComboBox();

        for (int i = 0; i<list_instructor.size(); i++){
            instructorList.addItem(list_instructor.get(i));
        }
        instructorList.setSelectedIndex(0);

        ///
        String[] list_days = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday"};
        final JComboBox dayList = new JComboBox(list_days);
        dayList.setSelectedIndex(0); 

        final JTextField start_date = new JTextField(8);
        final JTextField end_date = new JTextField(8);

        String[] list_sessions;
        DefaultListModel sessionsListModel;
        sessionsListModel = new DefaultListModel();
        JList sessionsList = new JList(sessionsListModel);
        JScrollPane SessionListScroller = new JScrollPane(sessionsList);
        
        JButton searchButton = new JButton("Search Available Times");
        searchButton.addActionListener((ActionEvent e) -> {
            sessionsListModel.clear();
            String[] CourseID = courseList.getSelectedItem().toString().split(":");
            int theCourseID = Integer.parseInt( CourseID[0] );
            
            String[] InstructorID = instructorList.getSelectedItem().toString().split(":");
            int theInstructorID = Integer.parseInt( InstructorID[0] );
            String theStartDate = start_date.getText();
            String theEndDate = end_date.getText();
            String theDay = dayList.getSelectedItem().toString();
            
            if ((con.isStartDateBeforeEndDate(theStartDate, theEndDate) == true) && ( (con.dayOfTheWeek(theStartDate, theEndDate, theDay)) == true)) {
                ArrayList<Integer> BookedTimesByInstructor = new ArrayList<>();
                ArrayList<Integer> BookedTimesByRoom = new ArrayList<>();
                ArrayList<String> list_sessions1 = new ArrayList<>();
                con.viewAvailableSessions(theInstructorID, theCourseID, theStartDate, theEndDate, list_sessions1, BookedTimesByInstructor, BookedTimesByRoom, conn);
                
                if (list_sessions1.isEmpty()) {
                    JOptionPane.showMessageDialog(addFrame, "No available sessions found for the search criteria. Please Try again.", "Error Message",JOptionPane.ERROR_MESSAGE);
                
                } else {
                    for (int i = 0; i < list_sessions1.size(); i++) {
                        sessionsListModel.addElement(list_sessions1.get(i));
                    }
                
                }
            } else {
                JOptionPane.showMessageDialog(addFrame, "Invalid Start/End Dates chosen: Please choose in the format dd/MM/yyyy.", "Error Message",JOptionPane.ERROR_MESSAGE);
            
            }
        });
        
        JButton addButton = new JButton("Add a new session");
        addButton.addActionListener((ActionEvent e) -> {
            if (sessionsList.isSelectionEmpty() == true){
                JOptionPane.showMessageDialog(addFrame, "No sessions have been selected. Please Try again.", "Error Message",JOptionPane.ERROR_MESSAGE);
            } else {
                String[] CourseID = courseList.getSelectedItem().toString().split(":");
                int theCourseID = Integer.parseInt( CourseID[0] );
                
                String[] InstructorID = instructorList.getSelectedItem().toString().split(":");
                int theInstructorID = Integer.parseInt( InstructorID[0] );
                
                String theDay = dayList.getSelectedItem().toString();
                String theStartDate = start_date.getText();
                String theEndDate = end_date.getText();
                
                int theTime = -1;
                int theRoomID = -1;
                
                String sessionInput = (sessionsList.getSelectedValue()).toString();
                String firstSplit[];
                firstSplit = sessionInput.split(" ");
                String roomSplit;
                roomSplit = firstSplit[1];
                
                String timeSplit;
                timeSplit = firstSplit[3];
                
                String roomString[];
                roomString = roomSplit.split("\\.");
                theRoomID = Integer.parseInt( roomString[0] );
                
                String timeString[];
                timeString = timeSplit.split(":");
                theTime = Integer.parseInt( timeString[0] );
                
                con.add_session(theCourseID, theRoomID, theInstructorID, theStartDate, theEndDate, theTime, conn);
                JOptionPane.showMessageDialog(addFrame, "Successfully registered session for " + theDay + " from " + theStartDate + " to " + theEndDate + " with: " +
                        "\n Course: " + CourseID[1] +
                        "\n Room: " + roomSplit +
                        "\n Instructor: " + InstructorID[1] +
                        "\n Time: " + firstSplit[3] + " " + firstSplit[4] + " " + firstSplit[5], "Session Registration", JOptionPane.INFORMATION_MESSAGE);

                sessionsListModel.clear();
            }
        });

        JButton backButton = new JButton("Back");
        backButton.addActionListener((ActionEvent e) -> {
            setVisibility(mainFrame, true);
            setVisibility(addFrame, false);        
        });       
        
        searchPanel.add(CourseLabel);
        searchPanel.add(courseList);
      
        searchPanel.add(InstructorLabel);
        searchPanel.add(instructorList);
      
        searchPanel.add(DayLabel);       
        searchPanel.add(dayList);     
        
        searchPanel.add(StartDateLabel);       
        searchPanel.add(start_date);
        
        searchPanel.add(EndDateLabel);       
        searchPanel.add(end_date);
      
        searchPanel.add(backButton);
        searchPanel.add(searchButton);  

        if (RIGHT_TO_LEFT) {
            sessionPanel.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        }

	sessionPanel.setLayout(new GridBagLayout());
	GridBagConstraints c = new GridBagConstraints();
	if (shouldFill) {
	//natural height, maximum width
	c.fill = GridBagConstraints.HORIZONTAL;
	}

	if (shouldWeightX) {
	c.weightx = 0.5;
	}
        
        c.fill = GridBagConstraints.BOTH;
        c.ipady = 228; 
	c.gridx = 0;
	c.gridy = 0;
	sessionPanel.add(SessionListScroller, c);

	c.fill = GridBagConstraints.BOTH;
	c.ipady = 0;       //reset to default
	c.anchor = GridBagConstraints.PAGE_END; //bottom of space
        c.weighty = 0.5;
	c.insets = new Insets(7,0,0,0);  //top padding
	c.gridx = 0;       //aligned with button 2
	c.gridwidth = 3;   //2 columns wide
	c.gridy = 2;       //third row
	sessionPanel.add(addButton, c);
        
        addFrame.setVisible(true);
    }
}
