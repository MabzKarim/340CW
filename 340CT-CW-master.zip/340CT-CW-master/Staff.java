package stockcontrolsystem;
/**
 *
 * @author karimm9
 */
public class Staff {
    //Staff Fields
    private int user_id = -1;
    private String password = "";
    private String firstname = "";
    private String lastname = "";
    private int stafflevel = -1;


    //Returns Staff Fields
    public int getUserID(){
        return user_id;
    }
    public String getPassword(){
        return password;
    }
    public String getFirstname(){
        return firstname;
    }
    public String getLastname(){
        return lastname;
    }
    public int getStaffLevel(){
        return stafflevel;
    }
    
    //Assigns Staff Fields
    public void setUserID(int aRef){
        user_id = aRef;
    }
    public void setPassword (String aPassword){
        password = aPassword;
    }
    public void setFirstname(String aFirstname){
        firstname = aFirstname;
    }
    public void setLastname(String aLastname){
        lastname = aLastname;
    }
    public void setStaffLevel(int aRef){
        stafflevel = aRef;
    }
}