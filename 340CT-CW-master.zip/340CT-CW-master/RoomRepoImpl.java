/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ts_gui;

import java.sql.*;
import java.util.ArrayList;
/**
 *
 * @author karimm9
 */
public class RoomRepoImpl {
    //Defines all the Room Data Attricutes & Operations
    private ArrayList<Room> rooms;
    
    public RoomRepoImpl(){
        rooms = new ArrayList<>();
    }
    
    public RoomRepoImpl(ArrayList list){
        rooms = list;
    }
    
    public void addRoom(Room room, Connection conn){
        rooms.add(room); 
        write(conn,  "add",  room);
    }
    
    public Room getRoom(Room room){
        return rooms.get(room.getRoomID());
    }
    
    public ArrayList<Room> getAllRoom(){
        return rooms;
    }
    
    public void setRoom(ArrayList list){
        rooms = list;
    }
    
    public ArrayList read(Connection conn){
        //This operation will read all the Room records from the ROOM TABLE
        System.out.println("Reading from the database... ");
        //Defines the Room List which wil store all the Room records from the ROOM TABLE
        ArrayList list = new ArrayList();
        try {
            //Defines and execute the SQL statement to be executed - Select all the Room from the ROOM TABLE
            Statement st = conn.createStatement();
            ResultSet rs=null;
            String sql = "SELECT * FROM ROOM_TABLE";
            rs=st.executeQuery(sql);

            while(rs.next()){
                //Assigns all the Room attributes to the Room objects
                Room roo = new Room();
                roo.setRoomID(rs.getInt("ROOM_ID"));
                roo.setRoomType(rs.getString("ROOM_TYPE"));
                //Appends the Room objects to the Room list
                list.add(roo);
                System.out.println(rs.getInt("ROOM_ID")+"\t"+rs.getString("ROOM_TYPE"));
            }
            //Closes the ResultsSet & Statement objects used.
            rs.close();
            st.close();

        } catch (SQLException ex) {
            System.out.println("SQLException failed ! ");
        } 
        //Assigns the Room list to the Room data object
        rooms = list;
        System.out.println("room..." + list.size());
        
        return rooms;
    }
    
    public void write(Connection conn, String str, Room room){
        //This operation will write to the ROOM TABLE
        //Calls operation getAllRooms operation to assign all the Room records to the Room list
        ArrayList list = getAllRoom();
        System.out.println("Writing to the database... ");
        
        if (str.equals("add")){
            try {
                //Defines and creates the SQL statement to add a new Room records
                Statement st = conn.createStatement();
                String sql = "INSERT INTO ROOM_TABLE VALUES (" + room.getRoomID() + ", '" + room.getRoomType() + "')";
                //Executes the SQL statement
                st.executeUpdate(sql);
                //Closes the statement object used
                st.close();
            }
            catch (SQLException ex) {
                System.out.println("SQLException error ");
            }
        }
    }
}